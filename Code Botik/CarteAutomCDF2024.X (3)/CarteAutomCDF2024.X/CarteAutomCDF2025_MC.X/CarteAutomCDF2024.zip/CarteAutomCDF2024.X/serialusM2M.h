/* 
 * File:   serialusM2M.h
 * Author: AJREI
 *
 * Created on September 4, 2023, 4:54 PM
 */

// serialusM2M.h

#ifndef SERIALUS_M2M_H
#define SERIALUS_M2M_H

#include <stdint.h>
#include <stdbool.h>
#include "system.h"

#define BUFFER_SIZE 512 //

typedef struct {
    bool clignotement_en_cours;
    char buffer[BUFFER_SIZE];
    uint8_t head;
    uint8_t tail;
    bool carriageReturnReceived;
} SerialusM2M;

extern SerialusM2M serialusM2M;

void serialusM2M_init();
void serialusM2M_receive();
void serialusM2M_process();
void reset_rx_Buffer();
void reset_overflow_error();



void AX_set_ang();
void AX_set_pos();
void AX_set_led();
void AX_set_torque();
void AX_set_alim();

void AX_get_pos();
void AX_get_ping();

int16_t check_id_ax12_m2m(int16_t id);
void print_ping(uint8_t id);
void print_position_ax12(uint8_t id, int16_t position);
void print_erreur_ax12();
        


// Add other function declarations...


#endif
