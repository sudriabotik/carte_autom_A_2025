/*
 * File:   pump.c
 * Author: james
 *
 * Created on March 31, 2024, 10:59 AM
 */

#include "pump.h"
#include "system.h"
// Include the header where PORTB and PORTC are defined, e.g., xc.h or your specific device header.
#include "xc.h"

// Make sure to include the microcontroller's specific header file that defines LATA and LATC


// Implementations of functions to turn on pumps
void turnOnPump_ARM1(void) {
    LATBbits.LATB7 = 1; // Assuming PUMP_ARM1 is on LATBbits.LATB7
}

void turnOnPump_ARM2(void) {
    LATBbits.LATB8 = 1; // Adjusted to LAT register
}

void turnOnPump_ARM3(void) {
    LATBbits.LATB9 = 1; // Adjusted to LAT register
}

void turnOnPump_STOCK1(void) {
    LATCbits.LATC9 = 1; // Adjusted to LAT register
}

void turnOnPump_STOCK2(void) {
    LATCbits.LATC8 = 1; // Adjusted to LAT register
}

void turnOnPump_STOCK3(void) {
    LATCbits.LATC6 = 1; // Adjusted to LAT register
}

// Implementations of functions to turn off pumps
void turnOffPump_ARM1(void) {
    LATBbits.LATB7 = 0;
}

void turnOffPump_ARM2(void) {
    LATBbits.LATB8 = 0;
}

void turnOffPump_ARM3(void) {
    LATBbits.LATB9 = 0;
}

void turnOffPump_STOCK1(void) {
    LATCbits.LATC9 = 0;
}

void turnOffPump_STOCK2(void) {
    LATCbits.LATC8 = 0;
}

void turnOffPump_STOCK3(void) {
    LATCbits.LATC6 = 0;
}




void readSensors(unsigned char *sensorStates) {
    if (sensorStates != NULL) {
        // Reading presence sensors
        sensorStates[0] = SENSOR_PRESENCE1; // Read the state of presence sensor 1
        sensorStates[1] = SENSOR_PRESENCE2; // Read the state of presence sensor 2
        sensorStates[2] = SENSOR_PRESENCE3; // Read the state of presence sensor 3

        // Reading color sensors
        sensorStates[3] = SENSOR_COLOR1; // Read the state of color sensor 1
        sensorStates[4] = SENSOR_COLOR2; // Read the state of color sensor 2
        sensorStates[5] = SENSOR_COLOR3; // Read the state of color sensor 3
    }
}
